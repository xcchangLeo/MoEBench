# BenchScout WWW submission snapshot

This snapshot was compiled from `main.tex` with `latexmk -pdf -interaction=nonstopmode -halt-on-error`.
The PDF has 10 pages: eight pages of main content, one references page, and
one appendix page. The appendix marks the user-supplied GPU values as
non-evaluative provenance because run-level records and protocol metadata are
not included.

The manuscript is double blind. Reproduction scripts and raw run records are
distributed separately in the artifact bundle; no author identity is added to
this submission snapshot.
